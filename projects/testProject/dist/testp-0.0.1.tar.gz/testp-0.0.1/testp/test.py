def firstName(name):
	print name


firstName(raw_input("first name is: "))