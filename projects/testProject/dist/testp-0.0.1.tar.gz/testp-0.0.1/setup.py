try:
	from setuptools import setup
except ImportError:
	from distutils.core import setup

setup(
    name='testp',
    version='0.0.1',
    description='learning-py',
    license='MIT',
    packages=['testp'],
    author='steve jobs',
    author_email='zukarburg@gmail.com',
    keywords=[],
    url='nothigfor'
)

