import name

Name = name.your_name

print "loading file................................."
print "100% complete"

raw_input((" %s!!! press enter to read your file: ") % Name)
