#read a file named "readme" on my desktop

file_to_read = open("/home/emeka/Desktop/readme.txt")

print file_to_read.read()