def firstName(name):
	return name

your_name = firstName(raw_input("Name: "))