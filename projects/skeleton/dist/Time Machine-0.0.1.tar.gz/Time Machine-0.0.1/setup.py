try:
	from setuptools import setup
except ImportError:
	from distutils.core import setup

setup(
    name='Time Machine',
    version='0.0.1',
    description='taking you to the future',
    license='mit',
    packages=['name'],
    author='king of Time',
    author_email='oxygen@gmail.com',
    keywords=['future'],
    url='heynowbrowncow'
)
